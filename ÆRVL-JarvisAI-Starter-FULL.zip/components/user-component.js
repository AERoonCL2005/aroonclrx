import React, { useEffect } from 'react';
import '../styles/stars.css';

export default function UserComponent() {
  useEffect(() => {
    const audio = new Audio('/space-boot.mp3');
    audio.play();
  }, []);

  return (
    <div>
      <div id="stars"></div>
      <h2 className="welcome-text">Welcome to the world of</h2>
      <h1 className="jarvis-text">ÆRVLJarvisAI</h1>
    </div>
  );
}