import UserComponent from '../components/user-component';

export default function Home() {
  return (
    <div>
      <UserComponent />
    </div>
  );
}