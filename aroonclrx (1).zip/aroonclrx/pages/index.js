export default function Home() {
  return (
    <div style={{ textAlign: 'center', paddingTop: '100px', fontSize: '24px' }}>
      <h1>🚀 ยินดีต้อนรับสู่ ÆRoonCL R-X1</h1>
      <p>ระบบ AI ช่วยเหลือที่จริงจัง พร้อมให้คำปรึกษาแบบ Next-Level 💡</p>
    </div>
  )
}