import { useState } from 'react';

export default function Home() {
  const [messages, setMessages] = useState([{ role: 'assistant', content: 'สวัสดีค่ะ พี่รุ่นขา 💖 มีอะไรให้หนูช่วยไหมคะ?' }]);
  const [input, setInput] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    const userMessage = { role: 'user', content: input };
    setMessages([...messages, userMessage]);
    setInput('');

    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: [...messages, userMessage] }),
    });

    const data = await res.json();
    setMessages([...messages, userMessage, { role: 'assistant', content: data.result }]);
  }

  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>ÆRoonCL R-X1</h1>
      <div style={{ marginBottom: '1rem' }}>
        {messages.map((m, i) => (
          <p key={i}><strong>{m.role === 'user' ? 'พี่รุ่นขา' : 'ÆRoonCL'}:</strong> {m.content}</p>
        ))}
      </div>
      <form onSubmit={handleSubmit}>
        <input value={input} onChange={e => setInput(e.target.value)} style={{ width: '80%' }} />
        <button type="submit">ส่ง</button>
      </form>
    </main>
  );
}